(function($) {

    $('.col-3-js').addClass('col-md-3');
    $('.col-3-js').removeClass('col-md-12');

    $('.col-4-js').addClass('col-md-4');
    $('.col-4-js').removeClass('col-md-12');
    
    $('.col-6-js').addClass('col-md-6');
    $('.col-6-js').removeClass('col-md-12');

    $('.searchbox-surface').addClass('searchbox-surface--wide');
    $('.home-form').addClass('wide');

    $('.tipo-cidade-bairro').addClass('.col-md-12');
    $('.tipo-cidade-bairro').addClass('wide');

}(jQuery));